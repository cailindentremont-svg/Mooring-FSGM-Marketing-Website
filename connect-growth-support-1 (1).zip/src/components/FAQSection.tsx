import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQSection: React.FC = () => {
  const [openItems, setOpenItems] = useState<number[]>([]);
  const [activeCategory, setActiveCategory] = useState<'technicians' | 'organizations'>('technicians');

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(item => item !== index)
        : [...prev, index]
    );
  };

  const technicianFAQs = [
    {
      question: "Are there fees on work orders I accept?",
      answer: "No! We don't take any fees from work orders you accept. Our transparent pricing means you see exactly what the client pays, and we don't margin stack. There may be fees for other services outside of work orders."
    },
    {
      question: "What types of insurance are available?",
      answer: "We offer fractionalized general liability, professional liability, and equipment insurance. Our programs are designed specifically for independent contractors and are more affordable than traditional policies."
    },
    {
      question: "How quickly can I start getting work?",
      answer: "Once you complete our verification process (typically 3-5 business days), you can immediately browse and apply for available projects in your area."
    },
    {
      question: "What industries do you serve?",
      answer: "We specialize in telecom, IT, energy, and security sectors. Our technicians work on everything from fiber installations to data center maintenance."
    },
    {
      question: "Do I need specific certifications?",
      answer: "Requirements vary by project, but we help you obtain necessary certifications through our training programs. Many basic projects only require proven experience."
    },
    {
      question: "How does the vehicle program work?",
      answer: "We partner with financing companies to offer special rates on work vehicles and equipment. This includes both purchase and lease options with flexible terms."
    }
  ];

  const organizationFAQs = [
    {
      question: "How do you ensure technician quality?",
      answer: "All technicians undergo comprehensive background checks, skill assessments, and reference verification. We also maintain ongoing performance monitoring and customer feedback systems."
    },
    {
      question: "What compliance standards do you maintain?",
      answer: "We ensure all technicians meet OSHA safety standards, industry-specific certifications, and any custom compliance requirements your organization needs."
    },
    {
      question: "How quickly can you deploy technicians?",
      answer: "For standard projects, we can typically deploy qualified technicians within 24-48 hours. For specialized requirements, deployment time may vary based on certification needs."
    },
    {
      question: "What geographic coverage do you provide?",
      answer: "We have technicians in all 50 states, with particularly strong coverage in major metropolitan areas and key industrial regions."
    },
    {
      question: "How does pricing work?",
      answer: "Our pricing is competitive with traditional staffing while offering better flexibility. We provide transparent rate cards and can customize pricing for high-volume partnerships."
    },
    {
      question: "Can you integrate with our existing systems?",
      answer: "Yes! We offer API integrations and can work with your existing project management, scheduling, and reporting systems to ensure seamless operations."
    }
  ];

  const currentFAQs = activeCategory === 'technicians' ? technicianFAQs : organizationFAQs;

  return (
    <section id="faq" className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-gray-600">
            Get answers to common questions about working with Mooring Companies.
          </p>
        </div>

        <div className="flex justify-center mb-12">
          <div className="bg-gray-100 rounded-lg p-2">
            <button
              onClick={() => setActiveCategory('technicians')}
              className={`px-6 py-3 rounded-md font-semibold transition-all ${
                activeCategory === 'technicians'
                  ? 'bg-orange-500 text-white shadow-md'
                  : 'text-gray-600 hover:text-orange-500'
              }`}
            >
              For Technicians
            </button>
            <button
              onClick={() => setActiveCategory('organizations')}
              className={`px-6 py-3 rounded-md font-semibold transition-all ${
                activeCategory === 'organizations'
                  ? 'bg-blue-900 text-white shadow-md'
                  : 'text-gray-600 hover:text-blue-900'
              }`}
            >
              For Organizations
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {currentFAQs.map((faq, index) => (
            <div key={index} className="border border-gray-200 rounded-lg">
              <button
                onClick={() => toggleItem(index)}
                className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
              >
                <h3 className="text-lg font-semibold text-gray-900 pr-4">{faq.question}</h3>
                {openItems.includes(index) ? (
                  <ChevronUp className="w-5 h-5 text-gray-500 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-500 flex-shrink-0" />
                )}
              </button>
              {openItems.includes(index) && (
                <div className="px-6 pb-4">
                  <p className="text-gray-700 leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-4">Still have questions?</p>
          <button 
            onClick={() => {
              const contactSection = document.getElementById('contact');
              if (contactSection) {
                contactSection.scrollIntoView({ behavior: 'smooth' });
              }
            }}
            className="bg-blue-900 hover:bg-blue-800 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
          >
            Contact Our Team
          </button>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;