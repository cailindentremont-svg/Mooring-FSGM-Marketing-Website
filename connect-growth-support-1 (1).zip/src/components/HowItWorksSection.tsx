import React, { useState } from 'react';
import { UserCheck, Building, Handshake, TrendingUp, Search, FileCheck, Users, Award } from 'lucide-react';

const HowItWorksSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'technicians' | 'organizations'>('technicians');

  const technicianSteps = [
    {
      icon: <UserCheck className="w-8 h-8" />,
      title: "Apply & Get Verified",
      description: "Submit your application with certifications and experience. Our team verifies your credentials and background."
    },
    {
      icon: <FileCheck className="w-8 h-8" />,
      title: "Complete Onboarding",
      description: "Access compliance training, safety certifications, and insurance options. Get set up with our support systems."
    },
    {
      icon: <Search className="w-8 h-8" />,
      title: "Find Opportunities",
      description: "Browse available projects from our network of partner organizations. Choose work that fits your schedule and expertise."
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: "Grow Your Business",
      description: "Leverage our resources, tools, and support to expand your capabilities and increase your earning potential."
    }
  ];

  const organizationSteps = [
    {
      icon: <Building className="w-8 h-8" />,
      title: "Partner Assessment",
      description: "We evaluate your field service needs, compliance requirements, and geographic coverage goals."
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Custom Matching",
      description: "Our platform matches you with pre-vetted, compliant technicians who meet your specific requirements."
    },
    {
      icon: <Handshake className="w-8 h-8" />,
      title: "Seamless Integration",
      description: "Deploy technicians quickly with our streamlined onboarding and project management systems."
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: "Ongoing Support",
      description: "Benefit from continuous compliance monitoring, performance tracking, and dedicated account management."
    }
  ];

  const currentSteps = activeTab === 'technicians' ? technicianSteps : organizationSteps;

  return (
    <section id="how-it-works" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">How Mooring Companies Works</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our platform streamlines the connection between skilled technicians and organizations, ensuring compliance, quality, and growth for all parties.
          </p>
        </div>

        <div className="flex justify-center mb-12">
          <div className="bg-white rounded-lg p-2 shadow-lg">
            <button
              onClick={() => setActiveTab('technicians')}
              className={`px-8 py-3 rounded-md font-semibold transition-all ${
                activeTab === 'technicians'
                  ? 'bg-orange-500 text-white shadow-md'
                  : 'text-gray-600 hover:text-orange-500'
              }`}
            >
              For Technicians
            </button>
            <button
              onClick={() => setActiveTab('organizations')}
              className={`px-8 py-3 rounded-md font-semibold transition-all ${
                activeTab === 'organizations'
                  ? 'bg-blue-900 text-white shadow-md'
                  : 'text-gray-600 hover:text-blue-900'
              }`}
            >
              For Organizations
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {currentSteps.map((step, index) => (
            <div key={index} className="relative">
              <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow h-full">
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full mb-4 ${
                  activeTab === 'technicians' ? 'bg-orange-100 text-orange-500' : 'bg-blue-100 text-blue-900'
                }`}>
                  {step.icon}
                </div>
                <div className="absolute top-4 right-4 text-2xl font-bold text-gray-200">
                  {String(index + 1).padStart(2, '0')}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
              {index < currentSteps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                  <div className={`w-8 h-0.5 ${activeTab === 'technicians' ? 'bg-orange-300' : 'bg-blue-300'}`}></div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;