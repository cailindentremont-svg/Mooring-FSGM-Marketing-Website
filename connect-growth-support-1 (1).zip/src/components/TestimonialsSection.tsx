import React from 'react';
import { Star, Quote } from 'lucide-react';
const TestimonialsSection: React.FC = () => {
  const testimonials = [{
    rating: 5,
    text: "Mooring Companies transformed my business. The insurance options and continuous support helped me take on bigger projects with confidence. I've increased my income by 40% in just 8 months."
  }, {
    rating: 5,
    text: "The compliance management and quality of technicians through Mooring Companies is exceptional. We've reduced our operational costs by 25% while improving service delivery across all regions."
  }, {
    rating: 5,
    text: "The training resources and SME support are incredible. I've gained three new certifications and expanded into energy sector work. The zero-fee model means I keep everything I earn."
  }, {
    rating: 5,
    text: "Mooring Companies solved our nationwide coverage challenge. Their technician network is reliable, compliant, and professional. The custom onboarding process perfectly matched our requirements."
  }, {
    rating: 5,
    text: "The vehicle program helped me upgrade my equipment, and the health benefits are a game-changer. I finally have the support system I needed to grow my independent business."
  }, {
    rating: 5,
    text: "The rapid deployment capabilities and ongoing compliance monitoring have streamlined our operations significantly. We can now scale projects faster than ever before."
  }];
  const renderStars = (rating: number) => {
    return Array.from({
      length: 5
    }, (_, i) => <Star key={i} className={`w-4 h-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />);
  };
  return <section id="testimonials" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4" data-editor-uid="14656fe3-75c9-489b-bb9a-c39b1c69b50a" data-editor-name="h2" data-component-path="src/components/TestimonialsSection.tsx" data-component-line="69" data-static="true" data-editor-content="%7B%22text%22%3A%22Success%20Stories%22%2C%22className%22%3A%22text-4xl%20font-bold%20text-gray-900%20mb-4%22%7D">Success Stories</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-editor-uid="fa2b8b96-dd8b-4893-ab0a-ac30b4f65a5d" data-editor-name="p" data-component-path="src/components/TestimonialsSection.tsx" data-component-line="70" data-static="true" data-editor-content="%7B%22text%22%3A%22Hear%20from%20technicians%20and%20organizations%20who%20have%20transformed%20their%20field%20service%20operations%20with%20Mooring%20Companies.%22%2C%22className%22%3A%22text-xl%20text-gray-600%20max-w-3xl%20mx-auto%22%7D">
            Hear from technicians and organizations who have transformed their field service operations with Mooring Companies.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => <div key={index} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex mb-4">
                {renderStars(testimonial.rating)}
              </div>

              <div className="relative">
                <Quote className="absolute -top-2 -left-2 w-8 h-8 text-blue-200" />
                <p className="text-gray-700 italic pl-6">{testimonial.text}</p>
              </div>
            </div>)}
        </div>

        <div className="mt-16 text-center">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <div className="text-3xl font-bold text-blue-900" data-editor-uid="8a567c48-2a72-44bf-ac5a-77abacb5a7e7" data-editor-name="div" data-component-path="src/components/TestimonialsSection.tsx" data-component-line="106" data-static="true" data-editor-content="%7B%22text%22%3A%224.9%2F5%22%2C%22className%22%3A%22text-3xl%20font-bold%20text-blue-900%22%7D">4.9/5</div>
              <div className="text-gray-600" data-editor-uid="d893fc23-0637-4644-a616-cdc4748ded9f" data-editor-name="div" data-component-path="src/components/TestimonialsSection.tsx" data-component-line="107" data-static="true" data-editor-content="%7B%22text%22%3A%22Average%20Rating%22%2C%22className%22%3A%22text-gray-600%22%7D">Average Rating</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-900" data-editor-uid="b5faa8e0-fe07-4885-8e28-a40024950201" data-editor-name="div" data-component-path="src/components/TestimonialsSection.tsx" data-component-line="110" data-static="true" data-editor-content="%7B%22text%22%3A%2295%25%22%2C%22className%22%3A%22text-3xl%20font-bold%20text-blue-900%22%7D">97%</div>
              <div className="text-gray-600" data-editor-uid="7f7dcf1f-a978-4a6b-a2fb-88566f74030a" data-editor-name="div" data-component-path="src/components/TestimonialsSection.tsx" data-component-line="111" data-static="true" data-editor-content="%7B%22text%22%3A%22Client%20Retention%22%2C%22className%22%3A%22text-gray-600%22%7D">Client Retention</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-900" data-editor-uid="1ed0752e-a190-4a83-b3e4-af93952bd26b" data-editor-name="div" data-component-path="src/components/TestimonialsSection.tsx" data-component-line="114" data-static="true" data-editor-content="%7B%22text%22%3A%2248hrs%22%2C%22className%22%3A%22text-3xl%20font-bold%20text-blue-900%22%7D">48hrs</div>
              <div className="text-gray-600" data-editor-uid="245787a6-5794-4688-acc0-78de3e42a050" data-editor-name="div" data-component-path="src/components/TestimonialsSection.tsx" data-component-line="115" data-static="true" data-editor-content="%7B%22text%22%3A%22Avg.%20Deployment%20Time%22%2C%22className%22%3A%22text-gray-600%22%7D">Avg. Deployment Time</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-900" data-editor-uid="0b367023-44e9-4f69-950d-a087e713700e" data-editor-name="div" data-component-path="src/components/TestimonialsSection.tsx" data-component-line="118" data-static="true" data-editor-content="%7B%22text%22%3A%22%242M%2B%22%2C%22className%22%3A%22text-3xl%20font-bold%20text-blue-900%22%7D">$5M+</div>
              <div className="text-gray-600" data-editor-uid="f619ca9a-8518-4428-8519-2703d7f6e0d6" data-editor-name="div" data-component-path="src/components/TestimonialsSection.tsx" data-component-line="119" data-static="true" data-editor-content="%7B%22text%22%3A%22Technician%20Earnings%22%2C%22className%22%3A%22text-gray-600%22%7D">Technician Earnings</div>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default TestimonialsSection;