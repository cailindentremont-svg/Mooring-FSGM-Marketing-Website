import React from 'react';
import { Shield, DollarSign, BookOpen, Truck, Heart, Users, Globe, BarChart3, Clock, CheckCircle } from 'lucide-react';
const FeaturesSection: React.FC = () => {
  const technicianFeatures = [{
    icon: <DollarSign className="w-6 h-6" />,
    title: "Transparent Work Order Rates",
    description: "No margin stacking on work orders. See exactly what clients pay - we don't take a cut from your accepted work orders."
  }, {
    icon: <Shield className="w-6 h-6" />,
    title: "Fractionalized Insurance",
    description: "Access affordable insurance options tailored for independent contractors."
  }, {
    icon: <Truck className="w-6 h-6" />,
    title: "Vehicle & Tool Programs",
    description: "Special financing and leasing programs for equipment and vehicles."
  }, {
    icon: <BookOpen className="w-6 h-6" />,
    title: "Continuous Training",
    description: "Stay current with industry certifications and skill development programs."
  }, {
    icon: <Heart className="w-6 h-6" />,
    title: "Health & Safety Resources",
    description: "Comprehensive safety training and health benefit options."
  }, {
    icon: <Users className="w-6 h-6" />,
    title: "SME Support Team",
    description: "Access to subject matter experts for technical guidance and support."
  }];
  const clientFeatures = [{
    icon: <Globe className="w-6 h-6" />,
    title: "National Network",
    description: "Access to thousands of pre-vetted technicians across all regions."
  }, {
    icon: <CheckCircle className="w-6 h-6" />,
    title: "Compliance Management",
    description: "Automated compliance tracking and reporting for all regulations."
  }, {
    icon: <BarChart3 className="w-6 h-6" />,
    title: "Cost Savings",
    description: "Reduce overhead costs while maintaining service quality and coverage."
  }, {
    icon: <Clock className="w-6 h-6" />,
    title: "Rapid Deployment",
    description: "Deploy qualified technicians quickly with streamlined onboarding."
  }, {
    icon: <Users className="w-6 h-6" />,
    title: "Custom Onboarding",
    description: "Tailored onboarding processes that match your specific requirements."
  }, {
    icon: <Shield className="w-6 h-6" />,
    title: "Risk Mitigation",
    description: "Comprehensive background checks and insurance verification."
  }];
  return <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4" data-editor-uid="2e1b089a-2ff6-47b8-831a-4b7cd9a07468" data-editor-name="h2" data-component-path="src/components/FeaturesSection.tsx" data-component-line="75" data-static="true" data-editor-content="%7B%22text%22%3A%22Why%20Choose%20Mooring%20Companies%22%2C%22className%22%3A%22text-4xl%20font-bold%20text-gray-900%20mb-4%22%7D">Why Choose Mooring Companies</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-editor-uid="a9e1d67a-4375-4c89-a541-73dfeb93523a" data-editor-name="p" data-component-path="src/components/FeaturesSection.tsx" data-component-line="76" data-static="true" data-editor-content="%7B%22text%22%3A%22We%20provide%20comprehensive%20solutions%20that%20benefit%20both%20technicians%20and%20organizations%2C%20creating%20a%20win-win%20ecosystem%20for%20field%20services.%22%2C%22className%22%3A%22text-xl%20text-gray-600%20max-w-3xl%20mx-auto%22%7D">We provide comprehensive solutions that benefit both technicians and organizations, creating a win-win ecosystem for field services deployment.</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Technician Features */}
          <div>
            <div className="flex items-center mb-8">
              <div className="bg-orange-500 text-white p-3 rounded-lg mr-4">
                <Users className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900" data-editor-uid="2c0921db-d4c4-47f4-8ec7-19fe1b9b1dbc" data-editor-name="h3" data-component-path="src/components/FeaturesSection.tsx" data-component-line="89" data-static="true" data-editor-content="%7B%22text%22%3A%22For%20Technicians%22%2C%22className%22%3A%22text-2xl%20font-bold%20text-gray-900%22%7D">For Technicians</h3>
                <p className="text-gray-600" data-editor-uid="8b7cb499-159f-4ca7-b0b0-ece3a767f334" data-editor-name="p" data-component-path="src/components/FeaturesSection.tsx" data-component-line="90" data-static="true" data-editor-content="%7B%22text%22%3A%22Grow%20your%20business%20with%20our%20comprehensive%20support%22%2C%22className%22%3A%22text-gray-600%22%7D">Grow your business with our comprehensive support</p>
              </div>
            </div>
            <div className="grid gap-6">
              {technicianFeatures.map((feature, index) => <div key={index} className="flex items-start">
                  <div className="bg-orange-100 text-orange-500 p-2 rounded-lg mr-4 flex-shrink-0">
                    {feature.icon}
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-1">{feature.title}</h4>
                    <p className="text-gray-600">{feature.description}</p>
                  </div>
                </div>)}
            </div>
          </div>

          {/* Client Features */}
          <div>
            <div className="flex items-center mb-8">
              <div className="bg-blue-900 text-white p-3 rounded-lg mr-4">
                <Globe className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900" data-editor-uid="3f1e806c-796e-4e4c-a5d4-2e54312ec79a" data-editor-name="h3" data-component-path="src/components/FeaturesSection.tsx" data-component-line="115" data-static="true" data-editor-content="%7B%22text%22%3A%22For%20Organizations%22%2C%22className%22%3A%22text-2xl%20font-bold%20text-gray-900%22%7D">For Organizations</h3>
                <p className="text-gray-600" data-editor-uid="852e6dda-0691-4582-852a-f0f8b7231ae5" data-editor-name="p" data-component-path="src/components/FeaturesSection.tsx" data-component-line="116" data-static="true" data-editor-content="%7B%22text%22%3A%22Scale%20your%20operations%20with%20our%20reliable%20network%22%2C%22className%22%3A%22text-gray-600%22%7D">Scale your operations with our reliable network</p>
              </div>
            </div>
            <div className="grid gap-6">
              {clientFeatures.map((feature, index) => <div key={index} className="flex items-start">
                  <div className="bg-blue-100 text-blue-900 p-2 rounded-lg mr-4 flex-shrink-0">
                    {feature.icon}
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-1">{feature.title}</h4>
                    <p className="text-gray-600">{feature.description}</p>
                  </div>
                </div>)}
            </div>
          </div>
        </div>

        {/* Unique Offerings Highlight */}
        <div className="mt-20 bg-gradient-to-r from-blue-900 to-blue-800 rounded-2xl p-8 text-white">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold mb-4" data-editor-uid="c8f9c97d-31be-484b-a57f-2e7faf284970" data-editor-name="h3" data-component-path="src/components/FeaturesSection.tsx" data-component-line="138" data-static="true" data-editor-content="%7B%22text%22%3A%22Our%20Unique%20Offerings%22%2C%22className%22%3A%22text-3xl%20font-bold%20mb-4%22%7D">Our Unique Offerings</h3>
            <p className="text-blue-100 text-lg" data-editor-uid="92025854-1def-495f-a0e2-cf1f5596de66" data-editor-name="p" data-component-path="src/components/FeaturesSection.tsx" data-component-line="139" data-static="true" data-editor-content="%7B%22text%22%3A%22Industry-leading%20solutions%20that%20set%20us%20apart%22%2C%22className%22%3A%22text-blue-100%20text-lg%22%7D">Industry-leading solutions that set us apart</p>
          </div>
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div className="bg-white/10 rounded-lg p-6">
              <Shield className="w-12 h-12 text-orange-400 mx-auto mb-4" />
              <h4 className="font-semibold mb-2" data-editor-uid="36d05042-de47-476a-bb6a-50726b87b2ca" data-editor-name="h4" data-component-path="src/components/FeaturesSection.tsx" data-component-line="144" data-static="true" data-editor-content="%7B%22text%22%3A%22Fractionalized%20Insurance%22%2C%22className%22%3A%22font-semibold%20mb-2%22%7D">Fractionalized Insurance</h4>
              <p className="text-sm text-blue-100" data-editor-uid="4d80bd5f-7683-44ee-ba59-af1a226ec6cd" data-editor-name="p" data-component-path="src/components/FeaturesSection.tsx" data-component-line="145" data-static="true" data-editor-content="%7B%22text%22%3A%22Affordable%20coverage%20options%22%2C%22className%22%3A%22text-sm%20text-blue-100%22%7D">Instant coverage on every job</p>
            </div>
            <div className="bg-white/10 rounded-lg p-6">
              <Truck className="w-12 h-12 text-orange-400 mx-auto mb-4" />
              <h4 className="font-semibold mb-2" data-editor-uid="9181966f-8602-4b17-85f9-4446bb49afa6" data-editor-name="h4" data-component-path="src/components/FeaturesSection.tsx" data-component-line="149" data-static="true" data-editor-content="%7B%22text%22%3A%22Vehicle%20Programs%22%2C%22className%22%3A%22font-semibold%20mb-2%22%7D">Vehicle Programs</h4>
              <p className="text-sm text-blue-100" data-editor-uid="5409f88b-8d5c-4136-8af7-0c47b908134d" data-editor-name="p" data-component-path="src/components/FeaturesSection.tsx" data-component-line="150" data-static="true" data-editor-content="%7B%22text%22%3A%22Equipment%20financing%20solutions%22%2C%22className%22%3A%22text-sm%20text-blue-100%22%7D">Solutions with no lengthy contract</p>
            </div>
            <div className="bg-white/10 rounded-lg p-6">
              <Heart className="w-12 h-12 text-orange-400 mx-auto mb-4" />
              <h4 className="font-semibold mb-2" data-editor-uid="98d5fc3f-fd97-46a9-ba00-695ee0aa8667" data-editor-name="h4" data-component-path="src/components/FeaturesSection.tsx" data-component-line="154" data-static="true" data-editor-content="%7B%22text%22%3A%22Health%20%26%20Safety%22%2C%22className%22%3A%22font-semibold%20mb-2%22%7D">Health & Safety</h4>
              <p className="text-sm text-blue-100" data-editor-uid="70da1966-f23a-48d3-b224-0ba578bb81ab" data-editor-name="p" data-component-path="src/components/FeaturesSection.tsx" data-component-line="155" data-static="true" data-editor-content="%7B%22text%22%3A%22Comprehensive%20safety%20resources%22%2C%22className%22%3A%22text-sm%20text-blue-100%22%7D">Comprehensive safety resources to ensure compliance</p>
            </div>
            <div className="bg-white/10 rounded-lg p-6">
              <Users className="w-12 h-12 text-orange-400 mx-auto mb-4" />
              <h4 className="font-semibold mb-2" data-editor-uid="6c482d3b-1df1-4499-9c62-053787ad259b" data-editor-name="h4" data-component-path="src/components/FeaturesSection.tsx" data-component-line="159" data-static="true" data-editor-content="%7B%22text%22%3A%22SME%20Support%22%2C%22className%22%3A%22font-semibold%20mb-2%22%7D">SME Support</h4>
              <p className="text-sm text-blue-100" data-editor-uid="9ab7a38f-ca3b-4a91-978a-45f9adaa97ff" data-editor-name="p" data-component-path="src/components/FeaturesSection.tsx" data-component-line="160" data-static="true" data-editor-content="%7B%22text%22%3A%22Expert%20technical%20guidance%22%2C%22className%22%3A%22text-sm%20text-blue-100%22%7D">Expert technical guidance when you need it</p>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default FeaturesSection;