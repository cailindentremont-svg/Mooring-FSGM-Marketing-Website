import React, { useState } from 'react';
import { Menu, X, Phone, Mail } from 'lucide-react';

interface HeaderProps {
  onJoinTechnician: () => void;
  onRequestDemo: () => void;
}

const Header: React.FC<HeaderProps> = ({ onJoinTechnician, onRequestDemo }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="text-2xl font-bold text-blue-900">
              Mooring Companies
            </div>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <button onClick={() => scrollToSection('how-it-works')} className="text-gray-700 hover:text-blue-900 transition-colors">
              How It Works
            </button>
            <button onClick={() => scrollToSection('features')} className="text-gray-700 hover:text-blue-900 transition-colors">
              Features
            </button>
            <button onClick={() => scrollToSection('testimonials')} className="text-gray-700 hover:text-blue-900 transition-colors">
              Testimonials
            </button>
            <button onClick={() => scrollToSection('faq')} className="text-gray-700 hover:text-blue-900 transition-colors">
              FAQ
            </button>
            <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-blue-900 transition-colors">
              Contact
            </button>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <button 
              onClick={onJoinTechnician}
              className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors"
            >
              Join as Technician
            </button>
            <button 
              onClick={onRequestDemo}
              className="bg-blue-900 hover:bg-blue-800 text-white px-4 py-2 rounded-lg font-semibold transition-colors"
            >
              Request Demo
            </button>
          </div>

          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <button onClick={() => scrollToSection('how-it-works')} className="block w-full text-left px-3 py-2 text-gray-700">
                How It Works
              </button>
              <button onClick={() => scrollToSection('features')} className="block w-full text-left px-3 py-2 text-gray-700">
                Features
              </button>
              <button onClick={() => scrollToSection('testimonials')} className="block w-full text-left px-3 py-2 text-gray-700">
                Testimonials
              </button>
              <button onClick={() => scrollToSection('faq')} className="block w-full text-left px-3 py-2 text-gray-700">
                FAQ
              </button>
              <button onClick={() => scrollToSection('contact')} className="block w-full text-left px-3 py-2 text-gray-700">
                Contact
              </button>
              <div className="pt-4 space-y-2">
                <button 
                  onClick={onJoinTechnician}
                  className="w-full bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg font-semibold"
                >
                  Join as Technician
                </button>
                <button 
                  onClick={onRequestDemo}
                  className="w-full bg-blue-900 hover:bg-blue-800 text-white px-4 py-2 rounded-lg font-semibold"
                >
                  Request Demo
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;