import React, { useState } from 'react';
import Header from './Header';
import HeroSection from './HeroSection';
import FeaturesSection from './FeaturesSection';
import HowItWorksSection from './HowItWorksSection';
import TestimonialsSection from './TestimonialsSection';
import FAQSection from './FAQSection';
import ContactSection from './ContactSection';
import Footer from './Footer';
import EmailNotificationSetup from './EmailNotificationSetup';

const AppLayout: React.FC = () => {
  const [showSetup, setShowSetup] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      {showSetup ? (
        <div className="min-h-screen bg-gray-50 py-8">
          <div className="max-w-6xl mx-auto px-4">
            <div className="mb-6">
              <button
                onClick={() => setShowSetup(false)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
              >
                ← Back to Website
              </button>
            </div>
            <EmailNotificationSetup />
          </div>
        </div>
      ) : (
        <>
          <Header />
          <main>
            <HeroSection />
            <FeaturesSection />
            <HowItWorksSection />
            <TestimonialsSection />
            <FAQSection />
            <ContactSection />
          </main>
          <Footer />
          
          {/* Setup Button */}
          <div className="fixed bottom-6 right-6 z-50">
            <button
              onClick={() => setShowSetup(true)}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-full font-semibold shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              📧 Email & Calendar Setup
            </button>
          </div>
        </>
      )}
    </div>
  );
};
export default AppLayout;
