import React, { useState } from 'react';
import { Mail, Calendar, Settings, CheckCircle, AlertCircle, Copy } from 'lucide-react';

const EmailNotificationSetup: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'setup' | 'calendar' | 'admin'>('setup');
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2000);
  };

  const sqlQueries = {
    createTable: `-- Create contacts table
CREATE TABLE contacts (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  user_type TEXT NOT NULL CHECK (user_type IN ('technician', 'organization')),
  company TEXT,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;

-- Create policy to allow inserts
CREATE POLICY "Allow public inserts" ON contacts FOR INSERT WITH CHECK (true);`,
    
    emailFunction: `-- Create email notification function
CREATE OR REPLACE FUNCTION notify_new_contact()
RETURNS TRIGGER AS $$
BEGIN
  -- This would integrate with your email service
  -- For now, it logs the contact submission
  RAISE NOTICE 'New contact submission: % (%) - %', NEW.name, NEW.email, NEW.message;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
CREATE TRIGGER contact_notification_trigger
  AFTER INSERT ON contacts
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_contact();`
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-xl shadow-lg">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Email & Calendar Integration Setup</h2>
        <p className="text-gray-600">Connect your contact form to email notifications and calendar scheduling</p>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 mb-8 bg-gray-100 p-1 rounded-lg">
        <button
          onClick={() => setActiveTab('setup')}
          className={`flex-1 py-2 px-4 rounded-md font-medium transition-colors ${
            activeTab === 'setup' 
              ? 'bg-white text-blue-600 shadow-sm' 
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Mail className="w-4 h-4 inline mr-2" />
          Email Setup
        </button>
        <button
          onClick={() => setActiveTab('calendar')}
          className={`flex-1 py-2 px-4 rounded-md font-medium transition-colors ${
            activeTab === 'calendar' 
              ? 'bg-white text-blue-600 shadow-sm' 
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Calendar className="w-4 h-4 inline mr-2" />
          Calendar Integration
        </button>
        <button
          onClick={() => setActiveTab('admin')}
          className={`flex-1 py-2 px-4 rounded-md font-medium transition-colors ${
            activeTab === 'admin' 
              ? 'bg-white text-blue-600 shadow-sm' 
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Settings className="w-4 h-4 inline mr-2" />
          Admin Panel
        </button>
      </div>

      {/* Email Setup Tab */}
      {activeTab === 'setup' && (
        <div className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-blue-900 mb-4">Step 1: Environment Variables</h3>
            <p className="text-blue-700 mb-4">Add these to your .env file:</p>
            <div className="bg-white p-4 rounded border font-mono text-sm relative">
              <button
                onClick={() => copyToClipboard('VITE_SUPABASE_URL=your_supabase_url\nVITE_SUPABASE_ANON_KEY=your_anon_key', 'env')}
                className="absolute top-2 right-2 p-1 hover:bg-gray-100 rounded"
              >
                {copied === 'env' ? <CheckCircle className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
              </button>
              <div>VITE_SUPABASE_URL=your_supabase_url</div>
              <div>VITE_SUPABASE_ANON_KEY=your_anon_key</div>
            </div>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-green-900 mb-4">Step 2: Database Setup</h3>
            <p className="text-green-700 mb-4">Run this SQL in your Supabase SQL editor:</p>
            <div className="bg-white p-4 rounded border font-mono text-xs relative max-h-64 overflow-y-auto">
              <button
                onClick={() => copyToClipboard(sqlQueries.createTable, 'table')}
                className="absolute top-2 right-2 p-1 hover:bg-gray-100 rounded"
              >
                {copied === 'table' ? <CheckCircle className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
              </button>
              <pre>{sqlQueries.createTable}</pre>
            </div>
          </div>

          <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-purple-900 mb-4">Step 3: Email Notifications</h3>
            <p className="text-purple-700 mb-4">Set up database triggers for email notifications:</p>
            <div className="bg-white p-4 rounded border font-mono text-xs relative max-h-64 overflow-y-auto">
              <button
                onClick={() => copyToClipboard(sqlQueries.emailFunction, 'function')}
                className="absolute top-2 right-2 p-1 hover:bg-gray-100 rounded"
              >
                {copied === 'function' ? <CheckCircle className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
              </button>
              <pre>{sqlQueries.emailFunction}</pre>
            </div>
          </div>

          <div className="bg-orange-50 border border-orange-200 rounded-lg p-6">
            <div className="flex items-start">
              <AlertCircle className="w-5 h-5 text-orange-500 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-orange-900 mb-2">Next Steps for Production</h4>
                <ul className="text-orange-700 space-y-1 text-sm">
                  <li>• Set up Supabase Edge Functions for email sending</li>
                  <li>• Integrate with email services like Resend, SendGrid, or Mailgun</li>
                  <li>• Configure email templates for different contact types</li>
                  <li>• Set up webhook endpoints for real-time notifications</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Calendar Integration Tab */}
      {activeTab === 'calendar' && (
        <div className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-blue-900 mb-4">Calendar Integration Options</h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white p-4 rounded-lg border">
                <h4 className="font-semibold text-gray-900 mb-3">Google Calendar API</h4>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• Automatically create calendar events</li>
                  <li>• Send meeting invitations</li>
                  <li>• Sync with your existing calendar</li>
                  <li>• Set up automated reminders</li>
                </ul>
              </div>
              
              <div className="bg-white p-4 rounded-lg border">
                <h4 className="font-semibold text-gray-900 mb-3">Calendly Integration</h4>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• Embed booking widget</li>
                  <li>• Automatic scheduling</li>
                  <li>• Time zone handling</li>
                  <li>• Buffer times and availability</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-green-900 mb-4">Implementation Steps</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">1</div>
                <div>
                  <h4 className="font-semibold text-green-900">Choose Integration Method</h4>
                  <p className="text-green-700 text-sm">Select between Google Calendar API or Calendly embedding</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">2</div>
                <div>
                  <h4 className="font-semibold text-green-900">Set Up API Credentials</h4>
                  <p className="text-green-700 text-sm">Configure OAuth or API keys for your chosen service</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">3</div>
                <div>
                  <h4 className="font-semibold text-green-900">Update Contact Form</h4>
                  <p className="text-green-700 text-sm">Add calendar scheduling options to your contact form</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Admin Panel Tab */}
      {activeTab === 'admin' && (
        <div className="space-y-6">
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Admin Dashboard Features</h3>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white p-4 rounded-lg border">
                <Mail className="w-8 h-8 text-blue-500 mb-3" />
                <h4 className="font-semibold text-gray-900 mb-2">Contact Management</h4>
                <p className="text-sm text-gray-600">View, respond to, and organize contact submissions</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg border">
                <Calendar className="w-8 h-8 text-green-500 mb-3" />
                <h4 className="font-semibold text-gray-900 mb-2">Appointment Tracking</h4>
                <p className="text-sm text-gray-600">Monitor scheduled meetings and follow-ups</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg border">
                <Settings className="w-8 h-8 text-purple-500 mb-3" />
                <h4 className="font-semibold text-gray-900 mb-2">Notification Settings</h4>
                <p className="text-sm text-gray-600">Configure email templates and notification preferences</p>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-yellow-900 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
                View All Contact Submissions
              </button>
              <button className="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
                Export Contact Data
              </button>
              <button className="w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
                Configure Email Templates
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmailNotificationSetup;