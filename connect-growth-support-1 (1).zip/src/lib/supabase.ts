import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || ''
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || ''

export const supabase = createClient(supabaseUrl, supabaseKey)

// Contact form submission type
export interface ContactSubmission {
  id?: string
  name: string
  email: string
  phone?: string
  user_type: 'technician' | 'organization'
  company?: string
  message: string
  created_at?: string
}

// Submit contact form to Supabase
export const submitContactForm = async (formData: Omit<ContactSubmission, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('contacts')
    .insert([formData])
    .select()

  if (error) {
    throw new Error(error.message)
  }

  return data
}

// Get all contact submissions (for admin use)
export const getContactSubmissions = async () => {
  const { data, error } = await supabase
    .from('contacts')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) {
    throw new Error(error.message)
  }

  return data
}